﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt6
{
    class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());


       // Tab[0,0] = " ";

        }    

            //private static int i;
            //i = 5; //ile pracowników
            //public Pracownik.pracownik[] tabpracownikow = new Pracownik.pracownik[i];

              
    


        
    }
}

 