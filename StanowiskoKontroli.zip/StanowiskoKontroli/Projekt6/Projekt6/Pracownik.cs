﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Projekt6.Pracownik;

namespace Projekt6
{
    
    public class Pracownik
    {
    //    public struct pracownik
    //    {
    //    int id;
    //    string imie;
    //    string nazwisko;
    //    string haslo;
    //    }

    //    //ile pracowników
    //    //public Pracownik.pracownik[] tab = new Pracownik.pracownik[5];
    //    public string[,] Tab = new string[5,4];
    //   // Tab[0,0] = " ";



    } 
    
}
