﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt6
{

    class generowanie_bedow
    {


        //public int x = System.DateTime.Now.Millisecond % System.DateTime.Now.Minute;
        Proces x = new Proces();
        
       
    

       
    }
}
