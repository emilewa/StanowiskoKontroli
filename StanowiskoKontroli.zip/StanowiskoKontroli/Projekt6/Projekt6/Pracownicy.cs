﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt6
{    
    public class Pracownicy
    {
        //const int i = 5; //ile pracowników
        //public Pracownik.pracownik[] tabpracownikow = new Pracownik.pracownik[i];
        //public List<int> listaid = new List<int>();
        //public List<string> listahasel = new List<string>();
        //List<string> listimie = new List<string>();
        //List<string> listnazwisko = new List<string>();

        ////zachownia
        //public void AddPraconik(int id, string haslo, string imie, string nazwisko)
        //{
        //    listaid.Add(id);
        //    listahasel.Add(haslo);
        //    listimie.Add(imie);
        //    listnazwisko.Add(nazwisko);
        //}
        

    }

    



}
